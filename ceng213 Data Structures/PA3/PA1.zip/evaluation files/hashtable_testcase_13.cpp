#include <iostream>

#include "HashTable.hpp"

/*
 * Case 13 : Constructor; insert an item; remove that item; insert it again; print hash table.
 */
int main() {
    HashTable<int> table;

    std::cout << "first, inserting an item with key \"jamesx\"" << std::endl;

    table.insert("jamesx", 10);

    table.print();

    std::cout << "then, removing the item with key \"jamesx\"" << std::endl;

    table.remove("jamesx");

    table.print();

    std::cout << "and finally, inserting another item with key \"jamesx\" again" << std::endl;

    table.insert("jamesx", 20);

    table.print();

    return 0;
}
