#include <iostream>

#include "TextEditor.hpp"

/*
 * Case 5 : Constructor; spellCheck with a correctly spelled word.
 */
int main() {
    TextEditor teditor("document_1.txt", "dictionary.txt");

    std::cout << "calling spellCheck function with word \"clean\"" << std::endl;

    bool check = teditor.spellCheck("clean");

    std::cout << "it returns " << (check ? "true" : "false") << std::endl;

    return 0;
}
