#include <iostream>

#include "HashTable.hpp"

/*
 * Case 11 : Constructor; multiple inserts (+ rehash); multiple contains function calls; print hash table.
 */
int main() {
    HashTable<int> table;

    table.insert("jamesx", 10);
    table.insert("johnx", 20);
    table.insert("robertx", 30);
    table.insert("michaelx", 40);
    table.insert("williamx", 50);

    table.print();

    std::string names[] = {"jamesx", "johnx", "robertx", "michaelx", "williamx", "maryx", "patriciax", "lindax", "barbarax", "elizabethx"};

    for (int i = 0 ; i < 10 ; ++i) {
        bool result = table.contains(names[i]);

        if (result) {
            std::cout << "the hash table contains an item with key \"" << names[i] << "\""<< std::endl;
        } else {
            std::cout << "the hash table does not contain an item with key \"" << names[i] << "\"" << std::endl;
        }
    }

    table.print();

    return 0;
}
