#include <iostream>

#include "HashTable.hpp"

/*
 * Case 3 : Constructor; remove,contains and find functions on empty hash table; print hash table.
 */
int main() {
    HashTable<int> table;

    // remove
    std::cout << "trying to remove the item with key \"jamesx\" from an empty hash table returns " << (table.remove("jamesx") ? "true" : "false") << std::endl;

    // contains
    std::cout << "does an empty hash table contain an item with key \"jamesx\"? " << (table.contains("jamesx") ? "true" : "false") << std::endl;

    // find
    const HashTableItem<int> *temp = table.find("jamesx");
    if (temp == NULL) {
        std::cout << "trying to find the item with key \"jamesx\" in an empty hash table returns NULL" << std::endl;
    } else {
        std::cout << "trying to find the item with key \"jamesx\" in an empty hash table returns the HashTableItem \"" << *temp << "\"" << std::endl;
    }

    table.print();

    return 0;
}
