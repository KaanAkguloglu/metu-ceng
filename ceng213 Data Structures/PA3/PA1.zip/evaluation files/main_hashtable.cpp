#include <iostream>

#include "HashTable.hpp"

int main() {
    HashTable<int> table;

    table.insert("abc", 1);
    table.insert("def", 2);
    table.insert("ghi", 3);

    table.print();

    table.remove("def");

    table.print();

    std::cout << "for abc" << table.contains("abc") << std::endl;
    std::cout << "for dec " <<table.contains("def") << std::endl;

    return 0;
}
