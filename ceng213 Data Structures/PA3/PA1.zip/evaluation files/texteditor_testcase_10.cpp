#include <iostream>

#include "TextEditor.hpp"

/*
 * Case 10 : Constructor; findAndReplaceWord; successful search.
 */
int main() {
    TextEditor teditor("document_1.txt", "dictionary.txt");

    // findAndReplaceWord(en, ceng)

    std::cout << "the text before calling findAndReplace function is \"" << teditor << "\"" << std::endl;

    std::cout << "calling findAndReplaceWord function with word \"en\" and replacement \"ceng\"" << std::endl;

    teditor.findAndReplaceWord("en", "ceng");

    std::cout << "the text after calling findAndReplace function is \"" << teditor << "\"" << std::endl;

    // findWord(en)

    std::cout << "calling findWord function with word \"en\"" << std::endl;

    std::vector<int> positions = teditor.findWord("en");

    std::cout << "returns following positions [";

    if (!positions.empty()) {
        for (int i = 0; i < positions.size() - 1; ++i) {
            std::cout << positions[i] << ", ";
        }
        std::cout << positions[positions.size() - 1];
    }

    std::cout << "]" << std::endl;

    // findWord(ceng)

    std::cout << "calling findWord function with word \"ceng\"" << std::endl;

    positions = teditor.findWord("ceng");

    std::cout << "returns following positions [";

    if (!positions.empty()) {
        for (int i = 0; i < positions.size() - 1; ++i) {
            std::cout << positions[i] << ", ";
        }
        std::cout << positions[positions.size() - 1];
    }

    std::cout << "]" << std::endl;

    return 0;
}
