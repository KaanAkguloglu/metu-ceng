#ifndef CARDATA_HPP
#define CARDATA_HPP

#include <ostream>
#include<cstdlib>

// DO NOT CHANGE THIS FILE.

class CarData {
	public:
		CarData();
		CarData(std::string modelName, int price);
		CarData(const CarData &obj);

		std::string getModelName() const;
		void setModelName(std::string modelName);
		
		int getPrice() const;
		void setPrice(int price);

		friend std::ostream &operator<<(std::ostream &os, const CarData &obj);
		
		bool operator==(const CarData &rhs);
		bool operator<=(const CarData &rhs);
		bool operator>=(const CarData &rhs);
		bool operator<(const CarData &rhs);
		bool operator>(const CarData &rhs);

	private:
		std::string modelName;
		int price;
};

#endif //CARDATA_HPP
