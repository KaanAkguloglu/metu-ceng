#include <iostream>

#include "Cars213.hpp"

int main()
{
	// Testing CarData and Cars213 together ...
    std::cout << "Testing CarData and Cars213 together ..." << std::endl;

    Cars213 onSale("sample_input1.txt");
	
	onSale.listMostExpensive(9);
	std::cout << std::endl;
	
    onSale.add("lada_niva", 20000);
    onSale.add("mercedes_e300", 560000);
	
	onSale.listMostExpensive(11);
	std::cout << std::endl;
	
	onSale.sold(220000);
	
	onSale.listMostExpensive(10);
	std::cout << std::endl;
	
    onSale.priceFilter(130000, 160000);
    return 0;
}