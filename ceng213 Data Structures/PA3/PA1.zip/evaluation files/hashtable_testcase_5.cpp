#include <iostream>

#include "HashTable.hpp"

/*
 * Case 5 : Constructor; multiple inserts (+ rehash); print hash table.
 */
int main() {
    HashTable<int> table;

    table.insert("jamesx", 10);
    table.print();

    table.insert("johnx", 20);
    table.print();

    table.insert("robertx", 30);
    table.print();

    table.insert("michaelx", 40);
    table.print();

    table.insert("williamx", 50);
    table.print();

    return 0;
}
