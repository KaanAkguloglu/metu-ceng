#include <iostream>

#include "HashTable.hpp"

/*
 * Case 2 : Constructor; getTableSize and getNumberOfItems on empty hash table; print hash table.
 */
int main() {
    HashTable<int> table;

    std::cout << "current table size is " << table.getTableSize() << std::endl;
    std::cout << "current number of items is " << table.getNumberOfItems() << std::endl;

    table.print();

    return 0;
}
