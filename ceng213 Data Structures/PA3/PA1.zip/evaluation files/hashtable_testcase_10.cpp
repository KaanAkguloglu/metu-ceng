#include <iostream>

#include "HashTable.hpp"

/*
 * Case 10 : Constructor; multiple inserts (+ rehash); multiple removes; multiple inserts again; print hash table.
 */
int main() {
    HashTable<int> table;

    table.insert("jamesx", 10);
    table.insert("johnx", 20);
    table.insert("robertx", 30);
    table.insert("michaelx", 40);
    table.insert("williamx", 50);
    table.insert("davidx", 60);
    table.insert("richardx", 70);
    table.insert("charlesx", 80);
    table.insert("josephx", 90);
    table.insert("thomasx", 100);

    table.print();

    table.remove("davidx");
    table.remove("jamesx");
    table.remove("thomasx");
    table.remove("robertx");
    table.remove("charlesx");
    table.remove("williamx");
    table.remove("josephx");
    table.remove("johnx");
    table.remove("richardx");
    table.remove("michaelx");

    table.print();

    table.insert("maryx", 10);
    table.insert("patriciax", 20);
    table.insert("lindax", 30);
    table.insert("barbarax", 40);
    table.insert("elizabethx", 50);

    table.print();

    return 0;
}
