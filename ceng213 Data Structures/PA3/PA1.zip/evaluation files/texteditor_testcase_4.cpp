#include <iostream>

#include "TextEditor.hpp"

/*
 * Case 4 : Constructor; findAndReplaceWord; unsuccessful search.
 */
int main() {
    TextEditor teditor("document_1.txt", "dictionary.txt");

    // findAndReplaceWord(bbbb, cccc)

    std::cout << "the text before calling findAndReplace function is \"" << teditor << "\"" << std::endl;

    std::cout << "calling findAndReplaceWord function with word \"bbbb\" and replacement \"cccc\"" << std::endl;

    teditor.findAndReplaceWord("bbbb", "cccc");

    std::cout << "the text after calling findAndReplace function is \"" << teditor << "\"" << std::endl;

    // findWord(bbbb)

    std::cout << "calling findWord function with word \"bbbb\"" << std::endl;

    std::vector<int> positions = teditor.findWord("bbbb");

    std::cout << "returns following positions [";

    if (!positions.empty()) {
        for (int i = 0; i < positions.size() - 1; ++i) {
            std::cout << positions[i] << ", ";
        }
        std::cout << positions[positions.size() - 1];
    }

    std::cout << "]" << std::endl;

    // findWord(cccc)

    std::cout << "calling findWord function with word \"cccc\"" << std::endl;

    positions = teditor.findWord("cccc");

    std::cout << "returns following positions [";

    if (!positions.empty()) {
        for (int i = 0; i < positions.size() - 1; ++i) {
            std::cout << positions[i] << ", ";
        }
        std::cout << positions[positions.size() - 1];
    }

    std::cout << "]" << std::endl;

    return 0;
}
