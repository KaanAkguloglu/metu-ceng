#include <iostream>

#include "HashTable.hpp"

/*
 * Case 17 : Constructor; insert, remove, contains and find functions (+ infinite probing test); print hash table.
 */
int main() {
    HashTable<int> table;

    std::cout << "first, creating a hash table with all active items" << std::endl;

    table.insert("jamesx", 10);

    table.print();

    table.remove("jamesx");

    table.print();

    table.insert("johnx", 20);

    table.print();

    std::cout << "then, calling remove, contains and find functions with a key does not exist in the hash table" << std::endl;

    bool removeStatus = table.remove("robertx");
    std::cout << "remove returns " << (removeStatus ? "true" : "false") << std::endl;

    bool containsStatus = table.contains("robertx");
    std::cout << "contains returns " << (containsStatus ? "true" : "false") << std::endl;

    const HashTableItem<int> *item = table.find("robertx");
    if (item != NULL) {
        std::cout << "find returns the HashTableItem \"" << *item << "\"" << std::endl;
    } else {
        std::cout << "find returns NULL" << std::endl;
    }

    table.print();

    return 0;
}
