
#include "CarData.hpp"

// DO NOT CHANGE THIS FILE.

CarData::CarData()
{

}

CarData::CarData(std::string modelName, int price)
{
    this->modelName = modelName;
    this->price = price;
}

CarData::CarData(const CarData &obj)
{
    this->modelName = obj.modelName;
    this->price = obj.price;
}

std::string CarData::getModelName() const
{
    return modelName;
}

void CarData::setModelName(std::string modelName)
{
    this->modelName = modelName;
}

int CarData::getPrice() const
{
    return price;
}

void CarData::setPrice(int price)
{
    this->price = price;
}

std::ostream &operator<<(std::ostream &os, const CarData &obj)
{
    os << "Model Name: " << obj.modelName << " | Price: " << obj.price;
    return os;
}

bool CarData::operator==(const CarData &rhs)
{
    return this->price == rhs.price;
}

bool CarData::operator<=(const CarData &rhs)
{
    return this->price <= rhs.price;
}

bool CarData::operator>=(const CarData &rhs)
{
    return this->price >= rhs.price;
}

bool CarData::operator<(const CarData &rhs)
{
    return this->price < rhs.price;
}

bool CarData::operator>(const CarData &rhs)
{
    return this->price > rhs.price;
}
