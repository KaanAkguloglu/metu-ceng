#include "Cars213.hpp"

Cars213::Cars213()
{
	/* TODO */
}

Cars213::Cars213(std::string fileName)
{
	/* TODO */

    
	std::string modelName;
	int price;

	std::ifstream carsfile;

    carsfile.open(fileName.c_str());


	while(carsfile >> modelName >> price){

		CarData newcar(modelName,price);
		carL.insert(newcar);
	    
	}

    carsfile.close();
	
}

Cars213::~Cars213()
{
	
}
		
void Cars213::add(std::string modelName, int price)
{
    
    CarData newcar(modelName,price);
    
      
    carL.insert(newcar);
    
    
    
	
}

void Cars213::sold(int price)
{
	
	BSTNode<CarData> *cur;
	
    
	cur = carL.getRoot();
	
	
	while(cur && cur->data.getPrice() != price){
	    
        if( price < cur->data.getPrice()){
            cur = cur->left;
        }
        else{
            cur  = cur->right;
        }
    }
    
    if(cur) carL.remove(cur->data);
    
	
}

void Cars213::listMostExpensive(int k)
{
    int i=0;
	BSTNode<CarData> *cur;
	BST<CarData> temp_tree ;
    
	
    
	while(i<k){
	    if(carL.getRoot() ){
    	    cur = expensive(carL.getRoot());
    	    temp_tree.insert(cur->data);
    	    carL.remove(cur->data) ;
	    }
	    i++;
	}
	expensive_print(temp_tree.getRoot());
	i=0;
	while( i<k){
	    if(temp_tree.getRoot()){
    	    cur = cheap(temp_tree.getRoot());
    	    carL.insert(cur->data);
    	    temp_tree.remove(cur->data);
	    }
	    i++;
	}
}

void Cars213::listCheapest(int k)
{
	

	
	
	int i=0;
	BSTNode<CarData> *cur;
	BST<CarData> temp_tree ;
    
	while(i<k){
	    if(carL.getRoot() ){
    	    cur = cheap(carL.getRoot());
    	    temp_tree.insert(cur->data);
    	    carL.remove(cur->data) ;
	    }
	    i++;
	}
	cheap_print(temp_tree.getRoot());
	i=0;
	while( i<k){
	    if(temp_tree.getRoot()){
    	    cur = expensive(temp_tree.getRoot());
    	    carL.insert(cur->data);
    	    temp_tree.remove(cur->data);
	    }
	    i++;
	}
}

void Cars213::priceFilter(int min, int max)
{
	/* TODO */
	CarData min_node("min",min),max_node("max",max);
	
	filter_print(carL.getRoot(),min_node,max_node);
	
}