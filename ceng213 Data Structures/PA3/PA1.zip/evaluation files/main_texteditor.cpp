#include <iostream>

#include "TextEditor.hpp"

int main() {
    TextEditor teditor("document_1.txt", "dictionary.txt");

    std::cout << "calling findWord function with word \"en\"" << std::endl;

    std::vector<int> positions = teditor.findWord("en");

    std::cout << "returns following positions [";

    if (!positions.empty()) {
        for (int i = 0; i < positions.size() - 1; ++i) {
            std::cout << positions[i] << ", ";
        }
        std::cout << positions[positions.size() - 1];
    }

    std::cout << "]" << std::endl;

    return 0;
}
