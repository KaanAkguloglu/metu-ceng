#include <iostream>

#include "HashTable.hpp"

/*
 * Case 6 : Constructor; insert duplicate (+ rehash); rehash; print hash table.
 */
int main() {
    HashTable<int> table;

    std::cout << "first, inserting an item with key \"jamesx\"" << std::endl;

    table.insert("jamesx", 10);

    table.print();

    std::cout << "then, trying to insert another item with the same key \"jamesx\"" << std::endl;

    bool status = table.insert("jamesx", 20);

    std::cout << "it returns " << (status ? "true" : "false") << std::endl;

    table.print();

    return 0;
}
