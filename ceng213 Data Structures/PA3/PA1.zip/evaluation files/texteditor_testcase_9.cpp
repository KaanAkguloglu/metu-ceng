#include <iostream>

#include "TextEditor.hpp"

/*
 * Case 9 : Constructor; getSuggestedWords with a misspelled word, but this time no suggested words exist.
 */
int main() {
    TextEditor teditor("document_1.txt", "dictionary.txt");

    std::cout << "calling getSuggestedWords function with word \"abcdef\"" << std::endl;

    std::vector<std::string> suggestedWords = teditor.getSuggestedWords("abcdef");

    std::cout << "returns following suggested words [";

    if (!suggestedWords.empty()) {
        for (int i = 0; i < suggestedWords.size() - 1; ++i) {
            std::cout << suggestedWords[i] << ", ";
        }
        std::cout << suggestedWords[suggestedWords.size() - 1];
    }

    std::cout << "]" << std::endl;

    return 0;
}
