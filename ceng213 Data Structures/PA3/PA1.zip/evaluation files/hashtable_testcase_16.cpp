#include <iostream>

#include "HashTable.hpp"

/*
 * Case 16 : Constructor; insert an item; remove that item; find it; print hash table.
 */
int main() {
    HashTable<int> table;

    std::cout << "first, inserting an item with key \"jamesx\"" << std::endl;

    table.insert("jamesx", 10);

    table.print();

    std::cout << "then, removing the item with key \"jamesx\"" << std::endl;

    table.remove("jamesx");

    table.print();

    std::cout << "and finally, trying to find an item with key \"jamesx\"" << std::endl;

    const HashTableItem<int> *status = table.find("jamesx");

    if (status != NULL) {
        std::cout << "it returns the HashTableItem \"" << *status << "\"" << std::endl;
    } else {
        std::cout << "it returns NULL" << std::endl;
    }

    table.print();

    return 0;
}
