#include <iostream>

#include "TextEditor.hpp"

/*
 * Case 2 : Constructor; findWord; unsuccessful search.
 */
int main() {
    TextEditor teditor("document_1.txt", "dictionary.txt");

    std::cout << "calling findWord function with word \"bbbb\"" << std::endl;

    std::vector<int> positions = teditor.findWord("bbbb");

    std::cout << "returns following positions [";

    if (!positions.empty()) {
        for (int i = 0; i < positions.size() - 1; ++i) {
            std::cout << positions[i] << ", ";
        }
        std::cout << positions[positions.size() - 1];
    }

    std::cout << "]" << std::endl;

    return 0;
}
