#include <iostream>

#include "HashTable.hpp"

/*
 * Case 1 : Constructor; print hash table.
 */
int main() {
    HashTable<int> table;

    table.print();

    return 0;
}
