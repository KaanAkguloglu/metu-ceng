#include <iostream>

#include "HashTable.hpp"

/*
 * Case 7 : Constructor; multiple inserts (+ rehash); remove; print hash table.
 */
int main() {
    HashTable<int> table;

    table.insert("jamesx", 10);
    table.insert("johnx", 20);
    table.insert("robertx", 30);
    table.insert("michaelx", 40);
    table.insert("williamx", 50);
    table.insert("davidx", 60);
    table.insert("richardx", 70);
    table.insert("charlesx", 80);
    table.insert("josephx", 90);
    table.insert("thomasx", 100);

    table.print();

    table.remove("davidx");

    table.print();

    return 0;
}
