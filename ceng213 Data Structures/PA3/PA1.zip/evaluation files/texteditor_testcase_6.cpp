#include <iostream>

#include "TextEditor.hpp"

/*
 * Case 6 : Constructor; spellCheck with a misspelled word.
 */
int main() {
    TextEditor teditor("document_1.txt", "dictionary.txt");

    std::cout << "calling spellCheck function with word \"clwan\"" << std::endl;

    bool check = teditor.spellCheck("clwan");

    std::cout << "it returns " << (check ? "true" : "false") << std::endl;

    return 0;
}
