#include <iostream>

#include "HashTable.hpp"

/*
 * Case 12 : Constructor; multiple inserts (+ rehash); multiple find function calls; print hash table.
 */
int main() {
    HashTable<int> table;

    table.insert("jamesx", 10);
    table.insert("johnx", 20);
    table.insert("robertx", 30);
    table.insert("michaelx", 40);
    table.insert("williamx", 50);

    table.print();

    std::string names[] = {"jamesx", "johnx", "robertx", "michaelx", "williamx", "maryx", "patriciax", "lindax", "barbarax", "elizabethx"};

    for (int i = 0 ; i < 10 ; ++i) {
        const HashTableItem<int> *result = table.find(names[i]);

        if (result != NULL) {
            std::cout << "find(\"" << names[i] << "\") returns the HashTableItem \"" << *result << "\"" << std::endl;
        } else {
            std::cout << "find(\"" << names[i] << "\") returns NULL" << std::endl;
        }
    }

    table.print();

    return 0;
}
