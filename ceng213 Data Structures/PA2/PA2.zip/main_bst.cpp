#include <iostream>

#include "BST.hpp"

int main()
{
	// Testing BSTNode ...
    std::cout << "Testing BSTNode ..." << std::endl;

    BSTNode<int> node(13, NULL, NULL);

    std::cout << "node : " << node << std::endl;

    // Testing BST ...
    std::cout << "Testing BST ..." << std::endl;

    BST<int> tree;

    tree.insert(6);
    tree.insert(34);
    tree.insert(13);
    tree.insert(27);

	tree.printInorder();
	tree.printReverseInorder();
	
	std::cout << "Depth of the node 13 is: " << tree.nodeDepth(tree.find(13)) << std::endl;
	
	tree.balanceTree();
	
    tree.printInorder();
	tree.printReverseInorder();
	
	std::cout << "Depth of the node 13 is: " << tree.nodeDepth(tree.find(13)) << std::endl;
	
	return 0;
}
