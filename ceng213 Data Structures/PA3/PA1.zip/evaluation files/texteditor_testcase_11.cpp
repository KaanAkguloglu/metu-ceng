#include <iostream>

#include "TextEditor.hpp"

/*
 * Case 11 : Constructor; getSuggestedWords with a misspelled word.
 */
int main() {
    TextEditor teditor("document_1.txt", "dictionary.txt");

    std::cout << "calling getSuggestedWords function with word \"nime\"" << std::endl;

    std::vector<std::string> suggestedWords = teditor.getSuggestedWords("nime");

    std::cout << "returns following suggested words [";

    if (!suggestedWords.empty()) {
        for (int i = 0; i < suggestedWords.size() - 1; ++i) {
            std::cout << suggestedWords[i] << ", ";
        }
        std::cout << suggestedWords[suggestedWords.size() - 1];
    }

    std::cout << "]" << std::endl;

    return 0;
}
