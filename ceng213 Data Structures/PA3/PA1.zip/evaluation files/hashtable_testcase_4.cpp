#include <iostream>

#include "HashTable.hpp"

/*
 * Case 4 : Constructor; insert on empty hash table; print hash table.
 */
int main() {
    HashTable<int> table;

    table.insert("jamesx", 10);

    table.print();

    return 0;
}
