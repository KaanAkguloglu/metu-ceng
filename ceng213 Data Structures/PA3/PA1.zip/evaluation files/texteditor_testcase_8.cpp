#include <iostream>

#include "TextEditor.hpp"

/*
 * Case 8 : Constructor; getSuggestedWords with a correctly spelled word.
 */
int main() {
    TextEditor teditor("document_1.txt", "dictionary.txt");

    std::cout << "calling getSuggestedWords function with word \"clean\"" << std::endl;

    std::vector<std::string> suggestedWords = teditor.getSuggestedWords("clean");

    std::cout << "returns following suggested words [";

    if (!suggestedWords.empty()) {
        for (int i = 0; i < suggestedWords.size() - 1; ++i) {
            std::cout << suggestedWords[i] << ", ";
        }
        std::cout << suggestedWords[suggestedWords.size() - 1];
    }

    std::cout << "]" << std::endl;

    return 0;
}
