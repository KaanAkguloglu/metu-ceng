#include <iostream>

#include "HashTable.hpp"

/*
 * Case 15 : Constructor; insert an item; remove that item; check if the hash table still contains it; print hash table.
 */
int main() {
    HashTable<int> table;

    std::cout << "first, inserting an item with key \"jamesx\"" << std::endl;

    table.insert("jamesx", 10);

    table.print();

    std::cout << "then, removing the item with key \"jamesx\"" << std::endl;

    table.remove("jamesx");

    table.print();

    std::cout << "and finally, checking if the hash table contains an item with key \"jamesx\"" << std::endl;

    bool status = table.contains("jamesx");

    std::cout << "it returns " << (status ? "true" : "false") << std::endl;

    table.print();

    return 0;
}
