#include <iostream>

#include "TextEditor.hpp"

/*
 * Case 3 : Constructor; findAndReplaceWord; successful search.
 */
int main() {
    TextEditor teditor("document_1.txt", "dictionary.txt");

    // findAndReplaceWord(ng, ceng)

    std::cout << "the text before calling findAndReplace function is \"" << teditor << "\"" << std::endl;

    std::cout << "calling findAndReplaceWord function with word \"ng\" and replacement \"ceng\"" << std::endl;

    teditor.findAndReplaceWord("ng", "ceng");

    std::cout << "the text after calling findAndReplace function is \"" << teditor << "\"" << std::endl;

    // findWord(ng)

    std::cout << "calling findWord function with word \"ng\"" << std::endl;

    std::vector<int> positions = teditor.findWord("ng");

    std::cout << "returns following positions [";

    if (!positions.empty()) {
        for (int i = 0; i < positions.size() - 1; ++i) {
            std::cout << positions[i] << ", ";
        }
        std::cout << positions[positions.size() - 1];
    }

    std::cout << "]" << std::endl;

    // findWord(ceng)

    std::cout << "calling findWord function with word \"ceng\"" << std::endl;

    positions = teditor.findWord("ceng");

    std::cout << "returns following positions [";

    if (!positions.empty()) {
        for (int i = 0; i < positions.size() - 1; ++i) {
            std::cout << positions[i] << ", ";
        }
        std::cout << positions[positions.size() - 1];
    }

    std::cout << "]" << std::endl;

    return 0;
}
